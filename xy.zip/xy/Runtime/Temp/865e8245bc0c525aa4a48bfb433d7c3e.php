<?php
//000000000000a:2:{s:2:"u1";s:3:"znh";s:2:"u2";s:13:"Administrator";}
?>